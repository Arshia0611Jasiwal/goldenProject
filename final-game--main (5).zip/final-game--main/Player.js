class Player{
    constructor(){
     

      
    }
}